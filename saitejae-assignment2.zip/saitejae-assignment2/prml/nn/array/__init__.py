from prml.nn.array.array import Array, array, asarray
from prml.nn.array.reshape import reshape_method
from prml.nn.function import broadcast, broadcast_to


Array.reshape = reshape_method
